import argparse
import os
import cv2
from multiprocessing import Process, Queue, freeze_support

parser = argparse.ArgumentParser()
parser.add_argument("-pp", "--parallelPolarized", help="Parallel polarized input images", required=True)
parser.add_argument("-cp", "--crossPolarized", help="Cross polarized input images", required=True)
parser.add_argument("-o", "--output", help="Output directory", required=True)
parser.add_argument("-t", "--threads", help=("number of rawtherapee threads to split the images into"), type=int,
                    required=False,
                    default=6)

args = parser.parse_args()

crossPolarized_directory = args.crossPolarized
parallelPolarized_images_directory = args.parallelPolarized
output_directory = args.output
threads_count = args.threads

cp_images = []
pp_images = []

images = []


def find_images():
    for root, dirs, files in os.walk(crossPolarized_directory):
        for file in files:
            if file.endswith(".jpg"):
                cp_images.append(os.path.join(root, file))

    for root, dirs, files in os.walk(parallelPolarized_images_directory):
        for file in files:
            if file.endswith(".jpg"):
                pp_images.append(os.path.join(root, file))

    for i in range(len(cp_images)):
        images.append([cp_images[i], pp_images[i]])


def subtractImages(task_queue, done_queue):
    for cross, parallel in iter(task_queue.get, 'STOP'):
        try:
            print("Subtracting " + cross + " from " + parallel)
            cp_image = cv2.imread(cross)
            pp_image = cv2.imread(parallel)
            difference = cv2.subtract(cp_image, pp_image)
            image_bw = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY)
            output = (output_directory + "\\" + cross.split("\\")[-1])
            cv2.imwrite(output, image_bw,
                        [int(cv2.IMWRITE_JPEG_QUALITY), 100])
            done_queue.put([cross, parallel])
        except Exception as e:
            print(e)
            pass


def workerTasks():
    if os.path.exists(output_directory):
        print("difference folder exists")
    else:
        os.mkdir(output_directory)
        print("difference folder created")

    task_queue = Queue()
    done_queue = Queue()

    for image in images:
        task_queue.put(image)

    print('task_queue size: ' + str(task_queue.qsize()))

    for i in range(threads_count):
        print("Starting thread %d" % i)
        Process(target=subtractImages, args=(task_queue, done_queue)).start()

    for i in range(len(cp_images)):
        print('output: \t', done_queue.get())

    for i in range(threads_count):
        task_queue.put('STOP')


if __name__ == '__main__':
    find_images()
    freeze_support()
    workerTasks()
    print("Done")
